document.addEventListener("DOMContentLoaded", handleWindowLoad) ; //Load the window

function handleWindowLoad() 
{

	var myVideo = document.querySelector("video"); //Variable of my video as myVideo
//----------------------PLAY/PAUSE BUTTON ---------------------------------------------------------------------------------------------------//
	var playButton = document.getElementById("playPause");

	playButton.addEventListener("click", playPauseVideo); //When the play button is clicked carry out the function playPauseVideo

	function playPauseVideo() 
	{
		if(myVideo.paused === true) //if the video is paused then
		{
			myVideo.play(); //play the video
			playButton.innerHTML = "Pause"; //Has the label on the button as Pause
			volumeSlider.value=1; //Set Volume to 100%
			volumeBar.value=100; //Sets Volume Bar to 100 - Indicating Full Volume
		}
		else //otherwise
		{
			myVideo.pause(); //pause the video
			playButton.innerHTML = "Play"; //Has The Label on the button as Play
		}

	}
//----------------------MUTE BUTTON ---------------------------------------------------------------------------------------------------//
	var MuteButton = document.getElementById("muteUnmute");
    MuteButton.addEventListener("click",muteUnmuteVideo); //When the mute button is clicked carry out the function muteUnmuteVideo

    function muteUnmuteVideo ()
    {
    	if (myVideo.muted === true) //If video is muted
    	{    
           myVideo.muted = false; //set the .muted function to false and set word on button to change
           muteUnmute.innerHTML = "Mute" //sets the word on the button to be mute
           volumeSlider.value=0.5; //When Unmuting the video set volume to 50%
           volumeBar.value=50; //Set volume Bar to 50 - Indicating Half Volume 
    	}
    	else 
    	{
    		myVideo.muted = true; //when the video is muted display unmute word on button
    		muteUnmute.innerHTML = "Unmute" //sets the label on the button to unmute 
    		volumeSlider.value=0; //Set Volume bar to 0 - Muted (Indicated Volume is muted)
    	}
    }	
//----------------------STOP BUTTON ---------------------------------------------------------------------------------------------------//
    var stopButton = document.getElementById("stopUnstop");
    stopButton.addEventListener("click",stopVideo); //When the stop button is clicked carry out the function stopVideo

    function stopVideo()
    {
    	if(myVideo.paused===false) //If the video is playing and button is clicked then
    	{
    		myVideo.pause(); //Pause The Video
    		myVideo.currentTime=0; //Set the time to the start of the vid
    		playButton.innerHTML="Play"; //Change the play button back to play as it will continue to say pause unless reset here
    		muteUnmute.innerHTML="Mute"; //Resets Mute Button to default
    		volumeBar.value=0; //When video is stopped reset the volume bar to 0 
    		playRate = 1;
    	}
    }
//----------------------SEEKER BAR ---------------------------------------------------------------------------------------------------//
    var scrubSlider = document.getElementById("seekBar");
    scrubSlider.addEventListener("input",scrubVideo); //When there is an input on the scrub slider carry out the function scrubVideo

    function scrubVideo()
    {
    	var scrubTime = myVideo.duration * (scrubSlider.value/100);
    	/*setting a new variable to getting the video duration and then 
    	finding the percentage and timesing these together
    	to get a percentage of what the bar has been moved by
    	so we can calculate where they want to move to */
    	myVideo.currentTime = scrubTime;
    }

    myVideo.addEventListener("timeupdate",movePlaySlider); //When there is a time update in the video carry out the function movePlayVideo

    function movePlaySlider()
    {
    	if(myVideo.currentTime>0) //if video is playing
    	{
    		scrubSlider.value = (myVideo.currentTime/myVideo.duration)*100; //current time of video divided by duration *100 to get percentage and move the video to that percentage//
    	}
    	else //if video is stopped
    	{
    		scrubSlider.value=0; //Set slider back to start
    	}
    }

    scrubSlider.addEventListener("mousedown", pauseSlider); //When there is a mouse down on the srcub slider carry out the function pauseSlider
    scrubSlider.addEventListener("mouseup", resumeSlider); //When there is a mouse up on the scrub slider carry out the function resumeSlider
    
    function pauseSlider() 
    {
    	myVideo.pause(); //When the mouse is held down on slider pause the video
    }

    function resumeSlider()
    {
    	myVideo.play(); //When the mouse is released on slider Play the video
    }
//----------------------VOLUME BAR ---------------------------------------------------------------------------------------------------//
	var volumeSlider = document.getElementById("volumeBar");
    volumeSlider.addEventListener("input",changeVolume);

    function changeVolume()
    {
    	var volumePercentage = volumeBar.value/100; // Set the Volume Bar Percentage to the value of the volume bar /100 as the whole volume bar has a max value of 100, this then gets the individual percentage
    	myVideo.volume = volumePercentage; //My Video Volume is equal to the volumeBar value /100
    }

    volumeSlider.addEventListener("volumechange",muteVolumeBar);
    function muteVolumeBar()
    {
    	if(volumeSlider.value>0) //If the volume Slider is not 0 then
    	{
    		volumeSlider.value=volumePercentage; //Set the video slider value to my video volume
    	}
    	else
    	{
    		volumeSlider.value=0; //Otherwise keep the video slider at 0 + Muted
    	}
    }
//--------------------PLAY BACK TIME -----------------------------------------------------------------------------------------------------//
	myVideo.addEventListener("timeupdate", displayPlaybackTime);

	function displayPlaybackTime()
	{
		var playBackDisplay = document.getElementById("playBackTime");
		var minutes = Math.floor (myVideo.currentTime/60); //Getting the minuites of the video by dividing the duration by 60 which gives us minuites, this then gets rounded down to a whole number by using the Math.Floor() method
		var seconds = Math.floor(myVideo.currentTime%60);  //getting the seconds of the video as a remainder of the minuites
		
		if(minutes<10) minutes = "0" + minutes; // If the minuites are less than 10 display the first number then a 0 to indicate a double digit number
		if(seconds<10) seconds = "0" + seconds; //If the seconds are less than 10 display 0 to inidicate :01 instead of just :1

		playBackDisplay.value = minutes + ":" + seconds;

	}
//--------------------DURATION BAR -------------------------------------------------------------------------------------------------------//    
	myVideo.addEventListener("durationchange", displayDuration);

	function displayDuration()
	{
		var durationDisplay = document.getElementById("durationField");
		var minutes = Math.floor (myVideo.duration/60); ////Getting the minuites of the video by dividing the duration by 60 which gives us minuites, this then gets rounded down to a whole number by using the Math.Floor() method
		var seconds = Math.floor(myVideo.duration%60);  //getting the seconds of the video as a remainder of the minuites
		
		if(minutes<10) minutes = "0" + minutes; // If the minuites are less than 10 display the first number then a 0 to indicate a double digit number
		if(seconds<10) seconds = ":" + seconds; //If the seconds are less than 10 display : then double digits

		durationDisplay.value = minutes + ":" + seconds; //Display minuites : seconds in the duration display field box
	}
//------------------SPEED OF PLAYBACK -----------------------------------------------------------------------------------------------------//
	var playRate= document.getElementById("rateOfPlayback");
	playRate.addEventListener("change", setPlaySpeed)
	
	function setPlaySpeed()
	{
	    myVideo.playbackRate = playRate.value; //the video playback rate is the value of the rate of playback option 
	    console.log(myVideo.playbackRate) //Indicates playack rate in the console log for testing
	}
//----------------FAST FORWARD BUTTON -----------------------------------------------------------------------------------------------------//
	var fastForwardbtn = document.getElementById("fastForward");
	fastForwardbtn.addEventListener("mousedown",tripleSpeed)

	function tripleSpeed()
	{
		myVideo.playbackRate = 3.0; //When Button Held Down Triple Speed Of Video
		console.log(myVideo.playbackRate)//Indicates playack rate in the console log for testing
	}

	fastForwardbtn.addEventListener("mouseup", doubleSpeed)

	function doubleSpeed()
	{
		myVideo.playbackRate = 2.0; //When Button Is Released Double Speed Of Video
		console.log(myVideo.playbackRate) //Indicates playack rate in the console log for testing
	}

	fastForwardbtn.addEventListener("dblclick", normalSpeed)

	function normalSpeed()
	{
		myVideo.playbackRate = 1.0; //When Button Is Double Clicked Restore Speed Of Video
		console.log(myVideo.playbackRate) //Indicates playack rate in the console log for testing
	}

}